#ifndef ULTIMATEBOARD_H
#define ULTIMATEBOARD_H
#include"BoardGame_Classes.h"
#include <bits/stdc++.h>
// SmallBoard Class Definition
template <typename T>
class SmallBoard:public Board<T> {
    
public:
    SmallBoard ();
    bool update_board (int x , int y , T symbol);
    void display_board () ;
    bool is_win() ;
    bool is_draw();
    bool game_is_over();

    T get_cell(int x, int y);// This method retrieves the value stored in the cell at row 'x' and column 'y'.
    // The 'x' and 'y' parameters represent the specific row and column of the sub-board.
    // It returns the value stored in the cell, which is of type T (typically 'char' or 'int' for player symbols like 'X' or 'O').
};
// UltimateBoard Class Definition
template <typename T>
class UltimateBoard:public Board<T> {
    private:
    SmallBoard<T>* subBoards[3][3];
    T metaBoard[3][3] = {};
    int currentSubBoardX = 0, currentSubBoardY = 0;
public:
    UltimateBoard ();
    bool update_board (int x , int y , T symbol);
    void display_board () ;
    bool is_win() ;
    bool is_draw();
    bool game_is_over();
    void set_current_sub_board(int x, int y);
};



template <typename T>
class HumanPlayer : public Player<T> {
public:
    HumanPlayer(string name, T symbol);
    void getmove(int& x, int& y) ;

};

template <typename T>
class Random_Player : public RandomPlayer<T>{
public:
    Random_Player (T symbol);
    void getmove(int &x, int &y) ;
};






 




template <typename T>
UltimateBoard<T>::UltimateBoard() {
     this->rows = 3;
        this->columns = 3;
         // Initialize each sub-board (3x3 grid of SmallBoards).
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                subBoards[i][j] = new SmallBoard<T>();
            }
        }
}

template <typename T>
bool UltimateBoard<T>::update_board(int x, int y, T symbol) {
    int subBoardX = x / 3;
        int subBoardY = y / 3;
        int cellX = x % 3;
        int cellY = y % 3;

        if (metaBoard[subBoardX][subBoardY] != 0)
            return false; // This sub-board is already won, no more moves

          // Update the sub-board with the symbol, and check if the move is valid.
        if (!subBoards[subBoardX][subBoardY]->update_board(cellX, cellY, symbol))
            return false;

        if (subBoards[subBoardX][subBoardY]->is_win())
            metaBoard[subBoardX][subBoardY] = symbol;

        this->n_moves++;
        return true;
}

// Display the board and the pieces on it
template <typename T>
void UltimateBoard<T>::display_board() {
    for (int i = 0; i < 3; ++i) {
            for (int subRow = 0; subRow < 3; ++subRow) {
                for (int j = 0; j < 3; ++j) {
                    for (int subCol = 0; subCol < 3; ++subCol) {
                        // Retrieve the symbol in the current sub-board at position (subRow, subCol)
                        T symbol = subBoards[i][j]->get_cell(subRow, subCol);
                        // Print the symbol; if it's 0 (empty), print a dot '.'
                        cout << (symbol == 0 ? '.' : symbol) << " ";
                    }
                    cout << "  ";
                }
                cout << endl;
            }
            cout << endl;
        }
}

// Returns true if there is any winner
template <typename T>
bool UltimateBoard<T>::is_win() {
    // Check rows and columns
    for (int i = 0; i < 3; ++i) {
        // Check rows in the meta-board.
            if (metaBoard[i][0] != 0 && metaBoard[i][0] == metaBoard[i][1] && metaBoard[i][1] == metaBoard[i][2])
                return true;
                // Check columns in the meta-board.
            if (metaBoard[0][i] != 0 && metaBoard[0][i] == metaBoard[1][i] && metaBoard[1][i] == metaBoard[2][i])
                return true;
        }
        // Check the two diagonals in the meta-board.
        if (metaBoard[0][0] != 0 && metaBoard[0][0] == metaBoard[1][1] && metaBoard[1][1] == metaBoard[2][2])
            return true;
        if (metaBoard[0][2] != 0 && metaBoard[0][2] == metaBoard[1][1] && metaBoard[1][1] == metaBoard[2][0])
            return true;
        return false;
}

// Return true if 9 moves are done and no winner
template <typename T>
bool UltimateBoard<T>::is_draw() {
    return this->n_moves == 81 && !is_win();
}

template <typename T>
bool UltimateBoard<T>::game_is_over() {
    return is_win() || is_draw();
}
// Sets the current sub-board (x, y) to be the next one to be played in.
template <typename T>
void UltimateBoard<T>::set_current_sub_board(int x, int y){
    currentSubBoardX = x % 3;
    currentSubBoardY = y % 3;
}




// Constructor for X_O_Board
template <typename T>
SmallBoard<T>::SmallBoard() {
    this->rows = 3;
        this->columns = 3;
        // Allocate memory for the 3x3 board and initialize all cells to 0 (empty).
        this->board = new T*[3];
        for (int i = 0; i < 3; ++i) {
            this->board[i] = new T[3]();
        }
}

template <typename T>
bool SmallBoard<T>::update_board(int x, int y, T symbol) {
    // Only update if move is valid
    if (x < 0 || x >= 3 || y < 0 || y >= 3 || this->board[x][y] != 0)
            return false;
        this->board[x][y] = symbol;
        this->n_moves++;
        return true;
}

// Display the board and the pieces on it
template <typename T>
void SmallBoard<T>::display_board() {
     for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                cout << (this->board[i][j] == 0 ? '.' : this->board[i][j]) << " ";
            }
            cout << endl;
        }
}

// Returns true if there is any winner
template <typename T>
bool SmallBoard<T>::is_win() {
    // Check rows and columns
    for (int i = 0; i < 3; ++i) {
            if (this->board[i][0] != 0 && this->board[i][0] == this->board[i][1] && this->board[i][1] == this->board[i][2])
                return true;
            if (this->board[0][i] != 0 && this->board[0][i] == this->board[1][i] && this->board[1][i] == this->board[2][i])
                return true;
        }
        if (this->board[0][0] != 0 && this->board[0][0] == this->board[1][1] && this->board[1][1] == this->board[2][2])
            return true;
        if (this->board[0][2] != 0 && this->board[0][2] == this->board[1][1] && this->board[1][1] == this->board[2][0])
            return true;
        return false;
}

// Return true if 9 moves are done and no winner
template <typename T>
bool SmallBoard<T>::is_draw() {
    return this->n_moves == 9 && !is_win();
}

template <typename T>
bool SmallBoard<T>::game_is_over() {
    return is_win() || is_draw();
}
 template <typename T>
T SmallBoard<T>:: get_cell(int x, int y){
    return this->board[x][y];
}





template <typename T>
HumanPlayer<T>::HumanPlayer(string name, T symbol) : Player<T>(name, symbol) {}

template <typename T>
void HumanPlayer<T>::getmove(int& x, int& y) {
   cout << "Enter your move (row column)(0,8): ";
        cin >> x >> y;
}

// Constructor for X_O_Random_Player
template <typename T>
Random_Player<T>::Random_Player(T symbol) : RandomPlayer<T>(symbol) {
    
    srand(static_cast<unsigned int>(time(0)));  // Seed the random number generator
}

template <typename T>
void Random_Player<T>::getmove(int& x, int& y) {
    x = rand() % 9;// Random x coordinate (0-8).
    y = rand() % 9;// Random y coordinate (0-8).
}






    #endif


