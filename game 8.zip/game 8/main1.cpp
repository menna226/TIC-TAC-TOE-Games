#include"BoardGame_Classes.h"
#include"UltimateGame.h"
#include"bits/stdc++.h"
using namespace std;
int main() {
    UltimateBoard<char> board;

    // Define player pointers
    Player<char>* player1 = nullptr;
    Player<char>* player2 = nullptr;

    string player1Name, player2Name;
    int player1Type, player2Type;

    // Ask Player 1 type
    cout << "Welcome to Ultimate Tic Tac Toe!\n";
   
    cout << "Is Player 1 a Human or a Random Computer?\n";
    cout << "1. Human\n";
    cout << "2. Random Computer\n";
    cout << "Enter your choice for Player 1 (1 or 2): ";
    cin >> player1Type;

    if (player1Type == 1) {
        cout << "Enter Player 1's name: ";
        cin >> player1Name;
        player1 = new HumanPlayer<char>(player1Name, 'X');
    } else if (player1Type == 2) {
        player1 = new Random_Player<char>('X');
    } else {
        cout << "Invalid choice for Player 1! Exiting game." << endl;
        return 1;
    }

    // Ask Player 2 type
    cout << "Is Player 2 a Human or a Random Computer?\n";
    cout << "1. Human\n";
    cout << "2. Random Computer\n";
    cout << "Enter your choice for Player 2 (1 or 2): ";
    cin >> player2Type;

    if (player2Type == 1) {
        cout << "Enter Player 2's name: ";
        cin >> player2Name;
        player2 = new HumanPlayer<char>(player2Name, 'O');
    } else if (player2Type == 2) {
        player2 = new Random_Player<char>('O');
    } else {
        cout << "Invalid choice for Player 2! Exiting game." << endl;
        delete player1; // Clean up Player 1 if Player 2 choice fails
        return 1;
    }

    // Set the board for each player
    player1->setBoard(&board);
    player2->setBoard(&board);

    // Create the array of players and start the game
    Player<char>* players[2] = { player1, player2 };
    GameManager<char> gameManager(&board, players);
    gameManager.run();

    // Clean up dynamic memory
    delete player1;
    delete player2;

    return 0;
}
